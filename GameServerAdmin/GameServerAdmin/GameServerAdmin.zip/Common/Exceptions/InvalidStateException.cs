﻿namespace GameServerAdmin.Common.Exceptions
{
    public class InvalidStateException : AppException
    {
        public InvalidStateException(string message) : base(ErrorCode.INVALID_STATE, message) { }

        public override int StatusCode => StatusCodes.Status409Conflict;
    }
}
